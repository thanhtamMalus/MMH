cmake_minimum_required(VERSION 3.16)
project(Lab4ECC CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Yeu cau OpenSSL phien ban >= 4.0
# Neu OpenSSL 4 cai o thu muc rieng: cmake -DOPENSSL_ROOT_DIR=/duong/dan/openssl4 ..
find_package(OpenSSL 4.0 REQUIRED COMPONENTS Crypto)
message(STATUS "Dung OpenSSL ${OPENSSL_VERSION}")

# Moi task la 1 file cpp, 1 chuong trinh
foreach(task task_a_ec_arith task_b_ec_keys task_c_ecdh)
  add_executable(${task} ${task}.cpp)
  target_link_libraries(${task} PRIVATE OpenSSL::Crypto)
  target_compile_options(${task} PRIVATE -Wall -Wextra)
  add_test(NAME ${task} COMMAND ${task})
endforeach()

enable_testing()
